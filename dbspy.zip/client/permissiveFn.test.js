const sum = require('./permissiveFn');

