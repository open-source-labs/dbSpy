import React from 'react';
import {render} from "@testing-library/react"
import userEvent from '@testing-library/user-event'
import FeatureTab from '../../src/components/DBDisplay/FeatureTab';

describe('Add Table Button', () => {
  it('should render table modal on click', )
})